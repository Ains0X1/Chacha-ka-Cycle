gdjs.Downhill_32Bike_32DemoCode = {};
gdjs.Downhill_32Bike_32DemoCode.localVariables = [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects5= [];


gdjs.Downhill_32Bike_32DemoCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backward"), gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Brake"), gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2);
gdjs.copyArray(runtimeScene.getObjects("DesktopControls"), gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2);
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2[i].getBehavior("Opacity").setOpacity(180);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2[i].hide();
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("LPedal"), gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
gdjs.copyArray(runtimeScene.getObjects("RPedal"), gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2);
gdjs.copyArray(runtimeScene.getObjects("RearSuspension"), gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWeldJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("Seat")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("Seat")), (gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0].getPointX("Connect")), (( gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0].getPointY("Connect")), 0, 30, 1, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("Crank")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("Crank")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0].getPointY("Centre")), false, 0, 0, 0, true, 10, 20, false, runtimeScene.getScene().getVariables().getFromIndex(16));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWheelJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("FrontWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("FrontWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointY("Centre")), 335, 14, 0.7, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWheelJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("RearWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("RearWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointY("Centre")), 90, 14, 0.7, true, 1, 50, false, runtimeScene.getScene().getVariables().getFromIndex(24));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getPointX("WheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getPointY("WheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointY("Centre")), false, 12, 0.7, 0, true, 150, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointX("RPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointY("RPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointY("Centre")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointX("LPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointY("LPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointY("Centre")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Head"), gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1);
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("LPedal"), gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1);
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("RPedal"), gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1);
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("SeatConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("SeatConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointX("Sit")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointY("Sit")), true, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(13));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("UConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("UConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1[0].getPointX("Connect")), (( gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1[0].getPointY("Connect")), true, 0, -(20), 20, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(25));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0].getPointY("UConnect")), false, 0, 100, -(45), false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(23));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0].getPointY("UConnect")), false, 0, 100, -(45), false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(21));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1[0].getPointY("LConnect")), true, 0, -(130), 0, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(22));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1[0].getPointY("LConnect")), true, 0, -(130), 0, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(20));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getPointX("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1[i].getPointY("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1[0].getPointY("Center")), false, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(12));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getPointX("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1[i].getPointY("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1[0].getPointY("Center")), false, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(11));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0].getPointY("UConnect")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointX("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1[i].getPointY("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0].getPointY("UConnect")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1[0].getPointY("LConnect")), true, 0, -(40), 85, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1[0].getPointY("LConnect")), true, 0, -(40), 85, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getPointX("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1[i].getPointY("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointX("Hands")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointY("Hands")), false, 0, 0, 0, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(17));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointX("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointY("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointX("Hands")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointY("Hands")), false, 0, 0, 0, false, 0, 0, false, runtimeScene.getScene().getVariables().getFromIndex(18));
}
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3000);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0.18);
}

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber() <= 1000);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(15).sub(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() > 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("186;255;66");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() > 250);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("250;237;86");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() > 500);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("245;166;35");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() > 750);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("255;105;65");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber() > 1000);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("255;0;0");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3);
gdjs.copyArray(runtimeScene.getObjects("ForceLabel"), gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3[i].drawLine((( gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3[0].getX()) + 20, 125, (( gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3[0].getX()) + (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() / 3) + 20, 125, 16);
}
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getBehavior("Physics2").getJointReactionForce(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber())));
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber() > runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ForceLabel"), gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(14).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3[i].getBehavior("Text").setText("Force: " + gdjs.evtTools.common.toString(Math.floor(runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber())));
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber() > runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(15).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber() > 0);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber() > 100);
}
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(50);
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList4 = function(runtimeScene) {

};gdjs.Downhill_32Bike_32DemoCode.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(11).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(18).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber());
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(23).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(21).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(20).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(22).getAsNumber(), true);
}
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList6 = function(runtimeScene) {

};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDHeadObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDTorsoObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRUpperArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLUpperArmObjects2Objects = Hashtable.newFrom({"Head": gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2, "Torso": gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2, "RArm": gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2, "LArm": gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2, "RUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2, "LUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects2Objects = Hashtable.newFrom({"Floor": gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects2, "Jump": gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2});
gdjs.Downhill_32Bike_32DemoCode.eventsList7 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2, gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3);

gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2, gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3);

gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2, gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);

{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(11).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(18).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[i].getBehavior("Physics2").removeJoint(runtimeScene.getScene().getVariables().getFromIndex(19).getAsNumber());
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(23).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(21).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(20).getAsNumber(), true);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(runtimeScene.getScene().getVariables().getFromIndex(22).getAsNumber(), true);
}
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("GameInstructions"), gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[k] = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DesktopControls"), gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3);
/* Reuse gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3 */
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3[i].hide();
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i].hide();
}
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList9 = function(runtimeScene) {

{

gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[k] = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).add(100);
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(runtimeScene.getScene().getVariables().getFromIndex(24).getAsNumber(), 50);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList10 = function(runtimeScene) {

{

gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Backward"), gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[k] = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(100);
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(runtimeScene.getScene().getVariables().getFromIndex(24).getAsNumber(), 50);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList11 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() < runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() > -(500));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).mul(0.99);
}
}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Brake"), gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[k] = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(runtimeScene.getScene().getVariables().getFromIndex(24).getAsNumber(), 1000);
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMotorSpeed(runtimeScene.getScene().getVariables().getFromIndex(24).getAsNumber(), 0);
}
}
}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[k] = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3[i].getBehavior("Physics2").applyTorque(38);
}
}
}

}


{

gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[i].IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[k] = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3[i].getBehavior("Physics2").applyTorque(-(38));
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMotorSpeed(runtimeScene.getScene().getVariables().getFromIndex(24).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
}
}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3);
for (var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[i].IsClicked(null) ) {
        isConditionTrue_1 = true;
        gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[k] = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final, gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Downhill Bike Demo", false);
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects3ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects3Objects = Hashtable.newFrom({"Floor": gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects3, "Jump": gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3});
gdjs.Downhill_32Bike_32DemoCode.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects3ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects3Objects, (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("Center")), 90, 5000, runtimeScene.getScene().getVariables().getFromIndex(5), runtimeScene.getScene().getVariables().getFromIndex(4), true);
if (isConditionTrue_0) {
/* Reuse gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3 */
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 300 / (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() - ((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("")) - 600)), "", 0);
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Follow"), gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[i].getPointX("")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointX("")), runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber()),gdjs.evtTools.common.lerp((gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[i].getPointY("")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("")), runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber()));
}
}
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[0] : null), true, "", 0);
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, ((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[0].getPointX("")) + 900) / 100, "Background", 0);
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFrontWheelObjects2Objects = Hashtable.newFrom({"FrontWheel": gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDStartObjects2Objects = Hashtable.newFrom({"Start": gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFrontWheelObjects1Objects = Hashtable.newFrom({"FrontWheel": gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDWinObjects1Objects = Hashtable.newFrom({"Win": gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1});
gdjs.Downhill_32Bike_32DemoCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFrontWheelObjects2Objects, gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDStartObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "elapsedTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TimeLabel"), gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "elapsedTimer"));
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2[i].getBehavior("Text").setText("Time: " + gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(9).getAsNumber()), 0, 5));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFrontWheelObjects1Objects, gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDWinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(1);
}
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList14 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("FrontSuspensionBottom"), gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
gdjs.copyArray(runtimeScene.getObjects("RearSuspension"), gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2[i].setPosition((( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointX("")),(( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointY("")));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2[i].setAngle((( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getAngle()));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].setAngle((( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getAngle()));
}
}
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").setRevoluteJointMotorSpeed(runtimeScene.getScene().getVariables().getFromIndex(16).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() / 4);
}
}
}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList3(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList4(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber() > 1000);
}
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(500);
}

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList6(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Head"), gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2);
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDHeadObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDTorsoObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRUpperArmObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLUpperArmObjects2Objects, "Physics2", gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects2ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10767444);
}
}
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(500);
}

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList11(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList12(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList13(runtimeScene);
}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDHeadObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDTorsoObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRUpperArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLUpperArmObjects1Objects = Hashtable.newFrom({"Head": gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1, "Torso": gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1, "RArm": gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1, "LArm": gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1, "RUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1, "LUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects1Objects = Hashtable.newFrom({"Floor": gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects1, "Jump": gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1});
gdjs.Downhill_32Bike_32DemoCode.eventsList15 = function(runtimeScene) {

{


gdjs.Downhill_32Bike_32DemoCode.eventsList1(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList14(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Head"), gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDHeadObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDTorsoObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDRUpperArmObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDLUpperArmObjects1Objects, "Physics2", gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDFloorObjects1ObjectsGDgdjs_9546Downhill_959532Bike_959532DemoCode_9546GDJumpObjects1Objects, false);
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(500);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Downhill Bike Demo", false);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Downhill_32Bike_32DemoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects5.length = 0;

gdjs.Downhill_32Bike_32DemoCode.eventsList15(runtimeScene);
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFloorObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimeLabelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceLabelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects5.length = 0;


return;

}

gdjs['Downhill_32Bike_32DemoCode'] = gdjs.Downhill_32Bike_32DemoCode;
